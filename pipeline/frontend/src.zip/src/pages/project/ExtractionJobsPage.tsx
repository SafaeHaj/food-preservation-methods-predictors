import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { jobsApi } from '../../services/api'
import type { Job } from '../../types'
import { RefreshCw, XCircle } from 'lucide-react'
import toast from 'react-hot-toast'
import clsx from 'clsx'

const STATUS_COLORS: Record<string, string> = {
  completed: 'text-green-700 bg-green-50',
  partial_success: 'text-yellow-700 bg-yellow-50',
  failed: 'text-red-700 bg-red-50',
  cancelled: 'text-gray-500 bg-gray-100',
  queued: 'text-blue-700 bg-blue-50',
  running: 'text-purple-700 bg-purple-50',
}

export default function ExtractionJobsPage() {
  const { projectId } = useParams<{ projectId: string }>()
  const [jobs, setJobs] = useState<Job[]>([])
  const [loading, setLoading] = useState(true)

  const load = () => {
    if (!projectId) return
    setLoading(true)
    jobsApi.list({ project_id: Number(projectId), limit: 50 } as Parameters<typeof jobsApi.list>[0])
      .then(setJobs)
      .finally(() => setLoading(false))
  }

  useEffect(() => {
    load()
    const interval = setInterval(load, 8000) // poll every 8 sec
    return () => clearInterval(interval)
  }, [projectId])

  const handleCancel = async (id: number) => {
    try {
      await jobsApi.cancel(id)
      toast.success('Job cancelled')
      load()
    } catch {
      toast.error('Cannot cancel job')
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-semibold text-gray-900">Extraction Jobs</h1>
        <button onClick={load} className="flex items-center gap-1 text-sm text-gray-600 border border-gray-300 rounded px-2 py-1">
          <RefreshCw size={14} /> Refresh
        </button>
      </div>

      {loading && jobs.length === 0 ? (
        <p className="text-gray-500 text-sm">Loading…</p>
      ) : jobs.length === 0 ? (
        <div className="text-center py-12 text-gray-400">No jobs yet. Upload PDFs to start extraction.</div>
      ) : (
        <div className="space-y-2">
          {jobs.map((job) => (
            <div key={job.id} className="bg-white border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className={clsx('px-2 py-0.5 rounded text-xs font-medium', STATUS_COLORS[job.status] ?? 'bg-gray-100 text-gray-600')}>
                    {job.status}
                  </span>
                  <span className="text-sm font-medium text-gray-800">{job.job_type}</span>
                  {job.paper_id && <span className="text-xs text-gray-400">Paper #{job.paper_id}</span>}
                </div>
                <div className="flex items-center gap-2">
                  {!['completed', 'failed', 'cancelled'].includes(job.status) && (
                    <button onClick={() => handleCancel(job.id)} className="text-red-400 hover:text-red-600" title="Cancel">
                      <XCircle size={16} />
                    </button>
                  )}
                  <span className="text-xs text-gray-400">{new Date(job.created_at).toLocaleString()}</span>
                </div>
              </div>
              {job.current_step && (
                <p className="text-xs text-gray-500 mt-2">{job.current_step}</p>
              )}
              {job.progress > 0 && (
                <div className="mt-2 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 rounded-full" style={{ width: `${job.progress}%` }} />
                </div>
              )}
              {job.error_message && (
                <p className="text-xs text-red-600 mt-2 font-mono">{job.error_message}</p>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
