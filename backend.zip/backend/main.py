"""
FastAPI backend for Shelf-Life Studio's React frontend.

This is a thin JSON wrapper around model_service.py -- it does not
reimplement any modeling, preprocessing, or prediction logic. Every number
returned here comes from the exact same ModelService the previous Dash
frontend (app.py) used, loaded once at startup from the saved artifacts.
NEVER retrains; NEVER touches train_models.py.

Usage:
    uvicorn backend.main:app --reload --port 8000
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Optional

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from model_service import BEST_MODEL_KEY, MODEL_LABELS, NONE_INGREDIENT_DESCRIPTORS, ModelService, build_candidate_row
from backend.assistant import AssistantService

SERVICE = ModelService()
CORE_MODELS = [m for m in ("random_forest", "lightgbm", "xgboost", "ebm", "lstm") if m in SERVICE.models]
ASSISTANT = AssistantService(SERVICE)

MODEL_BLURBS = {
    "random_forest": "Bagged ensemble of decision trees; robust baseline, resistant to overfitting.",
    "lightgbm": "Gradient-boosted trees optimized for speed on tabular data.",
    "xgboost": "Gradient-boosted trees with regularization; strong general-purpose accuracy.",
    "ebm": "Generalized additive model with pairwise interactions; every prediction fully decomposable.",
    "lstm": "Recurrent network run on the feature vector as an artificial sequence -- an experimental benchmark, not a natural fit for this cross-sectional data.",
}

app = FastAPI(title="Shelf-Life Studio API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _clean(obj: Any) -> Any:
    """Recursively replace NaN/inf with None so FastAPI's default JSON
    encoder (strict JSON, unlike Python's json module) never chokes."""
    if isinstance(obj, dict):
        return {k: _clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean(v) for v in obj]
    if isinstance(obj, float) and (np.isnan(obj) or np.isinf(obj)):
        return None
    if isinstance(obj, (np.floating,)):
        v = float(obj)
        return None if (np.isnan(v) or np.isinf(v)) else v
    if isinstance(obj, (np.integer,)):
        return int(obj)
    return obj


# ── Health / manifest / schema ──────────────────────────────────────────────

@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "best_model": SERVICE.best_model, "models": CORE_MODELS}


@app.get("/api/manifest")
def manifest() -> dict:
    return _clean({**SERVICE.manifest, "n_contexts_total": int(SERVICE.full_df["context_id"].nunique())})


@app.get("/api/schema")
def schema() -> dict:
    return _clean(SERVICE.schema)


@app.get("/api/lookups/matrix")
def matrix_lookup() -> dict:
    return _clean(SERVICE.matrix_lookup)


@app.get("/api/lookups/ingredient")
def ingredient_lookup() -> dict:
    return _clean(SERVICE.ingredient_lookup)


# ── Dataset workspaces (synthetic / real) ───────────────────────────────────

def _schema_preview(df: pd.DataFrame) -> list[dict]:
    rows = []
    for c in SERVICE.feature_cols:
        kind = "numeric" if c in SERVICE.numeric_cols else ("binary" if c in SERVICE.binary_cols else "categorical")
        miss_pct = float(df[c].isna().mean() * 100)
        example = df[c].dropna().iloc[0] if df[c].notna().any() else None
        rows.append({"column": c, "role": kind, "dtype": str(df[c].dtype), "missing_pct": miss_pct, "example": _clean(example)})
    return rows


@app.get("/api/dataset/synthetic")
def dataset_synthetic() -> dict:
    df = SERVICE.full_df
    real = df[df["data_origin"] == "real_paper_derived"]
    synth = df[df["data_origin"] != "real_paper_derived"]
    temp_hist_counts, temp_hist_edges = np.histogram(synth["storage_temperature_c"], bins=16)
    return _clean({
        "total_rows": len(synth),
        "contexts": int(synth["context_id"].nunique()),
        "controls": int((synth["is_control"] == 1).sum()),
        "treatments": int((synth["is_control"] == 0).sum()),
        "target_min": float(synth["shelf_life_days"].min()),
        "target_max": float(synth["shelf_life_days"].max()),
        "ingredient_families": synth[synth["primary_ingredient_family"] != "none"]["primary_ingredient_family"].value_counts().to_dict(),
        "storage_temperature_histogram": temp_hist_counts.tolist(),
        "storage_temperature_bin_edges": temp_hist_edges.tolist(),
        "shelf_life_histogram": np.histogram(synth["shelf_life_days"], bins=24)[0].tolist(),
        "shelf_life_bin_edges": np.histogram(synth["shelf_life_days"], bins=24)[1].tolist(),
        "generation_method": synth["data_origin"].mode().iat[0] if len(synth) else None,
        "has_real_subset": len(real) > 0,
        "schema_preview": _schema_preview(df)[:12],
    })


@app.get("/api/dataset/real")
def dataset_real() -> dict:
    """This dataset version is 100% synthetic (data_origin has a single
    value) -- there is no real, paper-derived subset to report. Reported
    honestly as zero rather than fabricated. The generation-rule breakdown
    (source_rule_id) is real, useful provenance info in its place."""
    df = SERVICE.full_df
    real = df[df["data_origin"] == "real_paper_derived"]
    rule_counts = df["source_rule_id"].value_counts().to_dict() if "source_rule_id" in df.columns else {}
    return _clean({
        "total_rows": len(real),
        "has_real_subset": len(real) > 0,
        "source_studies": [],
        "generation_rules": rule_counts,
        "quality_flags": df["quality_flag"].value_counts().to_dict(),
        "food_matrices": real["food_matrix"].value_counts().to_dict() if len(real) else {},
        "provenance_note": "This dataset version is entirely synthetic (data_origin is constant) -- there is no real, paper-derived subset. Every row's data_origin/quality_flag/training_weight/source_rule_id is excluded from model features to prevent leakage.",
    })


# ── Modeling ─────────────────────────────────────────────────────────────────

@app.get("/api/models")
def list_models() -> dict:
    ranked = sorted(CORE_MODELS, key=lambda m: SERVICE.metrics[m]["validation_rmse"])
    rows = []
    for m in ranked:
        met = SERVICE.metrics[m]
        rows.append({
            "id": m, "label": MODEL_LABELS[m], "blurb": MODEL_BLURBS[m],
            "is_best": m == SERVICE.best_model,
            "validation_r2": met["validation_r2"], "test_r2": met["test_r2"],
            "validation_rmse": met["validation_rmse"], "test_rmse": met["test_rmse"],
            "validation_mae": met["validation_mae"], "test_mae": met["test_mae"],
            "training_duration_sec": met["training_duration_sec"],
            "n_trainable_params": met.get("n_trainable_params"),
        })
    return _clean({
        "best_model": SERVICE.best_model,
        "models": rows,
        "manifest": SERVICE.manifest,
    })


@app.get("/api/models/{model}/details")
def model_details(model: str) -> dict:
    if model not in SERVICE.metrics:
        raise HTTPException(404, f"Unknown model: {model}")
    m = SERVICE.metrics[model]
    preds = SERVICE.predictions.query("model == @model")
    scatter = {
        split: preds[preds["split"] == split][["y_true", "y_pred"]].to_dict("records")
        for split in ("train", "validation", "test")
    }
    return _clean({
        "id": model, "label": MODEL_LABELS[model],
        "metrics": m,
        "curves": SERVICE.curves.get(model),
        "feature_importance": SERVICE.feature_importance.get(model, {}),
        "category_errors": SERVICE.category_errors.get(model, {}),
        "scatter": scatter,
    })


@app.get("/api/models/ebm/shapes")
def ebm_shapes(top_n: int = 4) -> dict:
    """EBM global shape functions for its top terms (by native importance),
    excluding pairwise-interaction terms. Same source data the previous Dash
    app's EBM shape-function charts used (ebm_model.explain_global())."""
    if "ebm" not in SERVICE.models:
        raise HTTPException(404, "EBM model not available")
    native = SERVICE.feature_importance.get("ebm", {}).get("native", {})
    top_terms = sorted(native.items(), key=lambda kv: abs(kv[1]), reverse=True)[:top_n]
    ebm_model = SERVICE.models["ebm"]
    global_exp = ebm_model.explain_global()
    names = list(global_exp.data()["names"])
    shapes = []
    for term, _ in top_terms:
        if term not in names:
            continue
        idx = names.index(term)
        d = global_exp.data(idx)
        shapes.append({
            "term": term,
            "type": d["type"],
            "names": [str(x) for x in d["names"]],
            "scores": [float(s) for s in d["scores"]],
        })
    return _clean({"shapes": shapes})


# ── Prediction ───────────────────────────────────────────────────────────────

class Candidate(BaseModel):
    name: str
    treatment_type: str
    application_method: str
    primary_ingredient_name: str
    primary_concentration: float
    primary_concentration_unit: str
    primary_ingredient_family: Optional[str] = None


class PredictRequest(BaseModel):
    model: str
    shared: dict[str, Any]
    candidates: list[Candidate]


@app.post("/api/predict")
def predict(req: PredictRequest) -> dict:
    if not req.candidates:
        raise HTTPException(400, "At least one candidate is required")
    try:
        candidates = [build_candidate_row(c.model_dump()) for c in req.candidates]
        result = SERVICE.compare_control_vs_candidates(req.model, req.shared, candidates)
    except Exception as exc:
        raise HTTPException(400, str(exc)) from exc
    return _clean(result)


class ExplainRequest(BaseModel):
    model: str
    row: dict[str, Any]
    top_k: int = 8


@app.post("/api/explain/local")
def explain_local(req: ExplainRequest) -> dict:
    try:
        factors = SERVICE.local_explanation(req.model, req.row, top_k=req.top_k)
    except Exception as exc:
        raise HTTPException(400, str(exc)) from exc
    return _clean({"factors": factors})


# ── Assistant ────────────────────────────────────────────────────────────────

class ChatMessage(BaseModel):
    role: str
    content: str


class AssistantChatRequest(BaseModel):
    messages: list[ChatMessage]
    page_context: Optional[dict[str, Any]] = None


@app.post("/api/assistant/chat")
def assistant_chat(req: AssistantChatRequest) -> dict:
    if not req.messages:
        raise HTTPException(400, "At least one message is required")
    try:
        result = ASSISTANT.chat(
            [m.model_dump() for m in req.messages],
            page_context=req.page_context,
        )
    except Exception as exc:
        raise HTTPException(502, str(exc)) from exc
    return _clean(result)


# ── References ───────────────────────────────────────────────────────────────

@app.get("/api/references")
def references() -> dict:
    """This dataset version has no real, paper-derived rows and no DOI-linked
    source_link column -- data_origin is constant (synthetic_literature_constrained)
    and provenance is instead tracked per-row via source_rule_id, a generation
    rule tag (e.g. RULE_ESSENTIAL_OIL), not a citation. Reported honestly."""
    return _clean(SERVICE.dataset_references())
