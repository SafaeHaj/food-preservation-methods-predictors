"""
LLM provider abstraction for the assistant.

AssistantService talks only to the LLMProvider interface below -- it never
calls Ollama's (or Groq's) HTTP API directly. Swapping LLM_PROVIDER=groq for
LLM_PROVIDER=ollama (or adding a third provider later) requires no changes
to AssistantService or the tool-dispatch loop, only a new provider class and
a line in get_provider().
"""
from __future__ import annotations

import abc
import os
from dataclasses import dataclass, field
from typing import Any

import requests


@dataclass
class ProviderMessage:
    """Normalized shape every provider must return from chat(), regardless
    of how the underlying API represents assistant turns and tool calls."""
    content: str | None
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    raw: dict[str, Any] | None = None


class LLMProvider(abc.ABC):
    @abc.abstractmethod
    def chat(self, messages: list[dict[str, Any]], tools: list[dict[str, Any]]) -> ProviderMessage:
        """messages: OpenAI-style [{role, content, ...}]. tools: OpenAI-style
        function-calling tool specs. Must return a ProviderMessage."""
        raise NotImplementedError


class OllamaProvider(LLMProvider):
    """Talks to a local Ollama server's /api/chat endpoint (OpenAI-compatible
    tool-calling support since Ollama 0.3+). Never called from Next.js --
    only ever invoked from this backend process."""

    def __init__(self, base_url: str | None = None, model: str | None = None, timeout: float = 180.0):
        self.base_url = (base_url or os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")).rstrip("/")
        # qwen3:4b was tried as a faster default but on this CPU it doesn't
        # reliably use structured tool calls -- it narrates its reasoning as
        # plain content instead of calling the tool, which breaks the "never
        # invent numbers" guarantee. qwen3:8b follows the tool-calling format
        # correctly, so it stays the default despite being slower per round.
        self.model = model or os.environ.get("OLLAMA_MODEL", "qwen3:8b")
        self.timeout = timeout

    def chat(self, messages: list[dict[str, Any]], tools: list[dict[str, Any]]) -> ProviderMessage:
        payload = {
            "model": self.model,
            "messages": messages,
            "tools": tools,
            "stream": False,
            "think": False,  # qwen3's chain-of-thought adds ~30-70s of latency on CPU for no
                              # accuracy benefit on these tool-routing decisions; keep it off.
            "options": {"temperature": 0.2, "num_predict": 350},  # bound worst-case generation length
        }
        try:
            resp = requests.post(f"{self.base_url}/api/chat", json=payload, timeout=self.timeout)
            resp.raise_for_status()
        except requests.exceptions.ConnectionError as exc:
            raise RuntimeError(
                f"Could not reach Ollama at {self.base_url}. Is it running? Start it with `ollama serve` "
                f"(or the desktop app) and make sure `{self.model}` is pulled (`ollama pull {self.model}`)."
            ) from exc
        data = resp.json()
        message = data.get("message", {})
        tool_calls = []
        for tc in message.get("tool_calls", []) or []:
            fn = tc.get("function", {})
            tool_calls.append({"name": fn.get("name"), "arguments": fn.get("arguments") or {}})
        return ProviderMessage(content=message.get("content"), tool_calls=tool_calls, raw=data)


class GroqProvider(LLMProvider):
    """OpenAI-compatible chat-completions provider for Groq. Included to
    demonstrate the abstraction is real (not speculative) -- swap
    LLM_PROVIDER=groq and set GROQ_API_KEY to use it, no other code changes."""

    def __init__(self, api_key: str | None = None, model: str | None = None, timeout: float = 60.0):
        self.api_key = api_key or os.environ.get("GROQ_API_KEY", "")
        self.model = model or os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")
        self.timeout = timeout
        self.base_url = "https://api.groq.com/openai/v1"

    def chat(self, messages: list[dict[str, Any]], tools: list[dict[str, Any]]) -> ProviderMessage:
        if not self.api_key:
            raise RuntimeError("GROQ_API_KEY is not set; cannot use LLM_PROVIDER=groq.")
        headers = {"Authorization": f"Bearer {self.api_key}"}
        payload = {"model": self.model, "messages": messages, "tools": tools, "temperature": 0.2}
        resp = requests.post(f"{self.base_url}/chat/completions", json=payload, headers=headers, timeout=self.timeout)
        resp.raise_for_status()
        data = resp.json()
        message = data["choices"][0]["message"]
        tool_calls = []
        for tc in message.get("tool_calls", []) or []:
            fn = tc.get("function", {})
            import json as _json
            args = fn.get("arguments")
            if isinstance(args, str):
                try:
                    args = _json.loads(args)
                except ValueError:
                    args = {}
            tool_calls.append({"name": fn.get("name"), "arguments": args or {}})
        return ProviderMessage(content=message.get("content"), tool_calls=tool_calls, raw=data)


def get_provider(name: str | None = None) -> LLMProvider:
    name = (name or os.environ.get("LLM_PROVIDER", "ollama")).lower()
    if name == "ollama":
        return OllamaProvider()
    if name == "groq":
        return GroqProvider()
    raise ValueError(f"Unknown LLM_PROVIDER: {name!r} (expected 'ollama' or 'groq')")
